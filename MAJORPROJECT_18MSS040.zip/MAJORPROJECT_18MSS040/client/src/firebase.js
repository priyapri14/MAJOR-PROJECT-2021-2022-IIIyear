import firebase from 'firebase/app';
import 'firebase/auth';

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBwpIe0yIlMyJ68KUMNbml8TVTxB6ISv_o",
    authDomain: "ecommerce-b5056.firebaseapp.com",
    projectId: "ecommerce-b5056",
    storageBucket: "ecommerce-b5056.appspot.com",
    messagingSenderId: "7270927292",
    appId: "1:7270927292:web:c4c18c77309ec225a4b9b9"

};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export const auth = firebase.auth();
export var googleAuthProvider = new firebase.auth.GoogleAuthProvider();
